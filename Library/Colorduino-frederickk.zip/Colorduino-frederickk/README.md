Colorduino
==========

Arduino Interface Library for ITeadStudio Colorduino and Colors Shield
Copyright (c) 2011 Sam C. Lin <lincomatic@hotmail.com>

To install, copy libraries/Colorduino to your <arduino sketchbook folder>/libraries/Colorduino folder.
ColorduinoPlasma.pde is a sample program which uses the library.  It displays an animated plasma on an 8x8 LED matrix

More information at http://blog.lincomatic.com/?p=148

